export const isObject = val => typeof val === 'object' && val !== null;
export const isArray = Array.isArray;
export const isFunction = val => typeof val === 'function';
export const isString = val => typeof val === 'string';
export const isSymbol = val => typeof val === 'symbol';

const hasOwnProperty = Object.prototype.hasOwnProperty;
export const hasOwn = (val, key) => hasOwnProperty.call(val, key);

// 字符串类型的数字，例如：'1'
export const isIntegerKey = key =>
    isString(key) &&
    key !== 'NaN' &&
    key[0] !== '-' &&
    '' + parseInt(key, 10) === key;

// 判断两个值是否严格不相等
export const hasChanged = (value, oldValue) => !Object.is(value, oldValue);
