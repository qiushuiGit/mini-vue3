import {
    isObject,
    isArray,
    hasOwn,
    isIntegerKey,
    hasChanged
} from '@vue/shared';
import { reactive, ReactiveFlags, reactiveMap, toRaw } from './reactive';
import { track, trigger } from './effect';

// 存放重写后的数组方法的对象
const arrayInstrumentations = createArrayInstrumentations();

// 重写数组方法，在实现上，内部依旧是通过原生的数组方法来调用，只是要做一些改变。
function createArrayInstrumentations() {
    const instrumentations = {};
    ['includes', 'indexOf', 'lastIndexOf'].forEach(key => {
        // this -> 原数组的代理对象，args -> 传入数组方法中的参数
        instrumentations[key] = function (this, ...args) {
            const arr = toRaw(this);

            for (let i = 0, l = this.length; i < l; i++) {
                track(arr, 'get', i + '');
            }

            // 通过数组的原生方法调用，倘若参数 args 是响应式的，则要用 toRaw 将其还原为原始对象，然后再调用。
            const res = arr[key](...args);

            if (res === -1 || res === false) {
                return arr[key](...args.map(toRaw));
            } else {
                return res;
            }
        };
    });

    ['push', 'pop', 'shift', 'unshift', 'splice'].forEach(key => {
        instrumentations[key] = function (this, ...args) {
            const arr = toRaw(this);
            // 通过数组的原生方法调用，并通过 apply 方法，防止this 指向改变
            const res = arr[key].apply(this, args);
            return res;
        };
    });

    return instrumentations;
}

const get = createGetter();

// done: createGetter 函数
function createGetter() {
    return function get(target, key, receiver) {
        // 当传入的 target 是已被代理过的 proxy 对象时，才会触发此条件。
        if (key === ReactiveFlags.IS_REACTIVE) {
            return true;
        } else if (
            // 当调用 toRaw 方法，返回代理对象的原始对象时，触发此条件。
            key === ReactiveFlags.RAW &&
            receiver === reactiveMap.get(target)
        ) {
            return target;
        }

        const targetIsArray = isArray(target);
        if (targetIsArray && hasOwn(arrayInstrumentations, key)) {
            // console.log(`数组-get-操作: key->${key}`);
            return Reflect.get(arrayInstrumentations, key, receiver);
        }

        // 依赖收集
        track(target, 'get', key);

        // Reflect.get 方法允许你从一个对象中取属性值。
        const result = Reflect.get(target, key, receiver);

        // 深度代理对象。在取值时，判断其是否为对象，若是，则对其进行代理，相对 vue2 上来就递归进行深度代理，性能大大提高。
        if (isObject(result)) {
            return reactive(result);
        }

        return result;
    };
}

const set = createSetter();

// done: createSetter 函数
function createSetter() {
    return function set(target, key, value, receiver) {
        let oldValue = target[key]; // 保存旧值

        // isArray 和 isIntegerKey 方法，是用来判断当前操作的对象是否为数组
        // Number(key) < target.length，为 真，则是对数组中的某个值进行修改，否则就是对数组执行新增，即添加值
        // hasOwn(target, key)，对象上是否存在某个属性，为真，则是修改，否则就是新增
        const hadKey =
            isArray(target) && isIntegerKey(key)
                ? Number(key) < target.length
                : hasOwn(target, key);

        // Reflect.set 方法允许你在对象上设置属性。它返回一个 Boolean 值表明是否成功设置属性。
        const result = Reflect.set(target, key, value, receiver);

        // hadKey 为 false，表示为对象执行新增操作，否则就是在修改。
        // 这样判断，是为了区分对数组的操作（新增或修改），以便知道当前在做什么。
        if (!hadKey) {
            console.log(`数组-set-新增操作: key->${key}, hadKey->${hadKey}`);
            trigger(target, 'add', key, value, oldValue);
        } else if (hasChanged(value, oldValue)) {
            console.log(`数组-set-修改操作: key->${key}, hadKey->${hadKey}`);
            trigger(target, 'set', key, value, oldValue);
        }

        return result;
    };
}

export const mutableHandlers = {
    get,
    set
};
