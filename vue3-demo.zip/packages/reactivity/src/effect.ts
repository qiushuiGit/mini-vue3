export let activeEffect = undefined; // 响应式对象

// 清除 effect
function cleanupEffect(effect) {
    // deps 中存储的是各被代理对象的属性所对应的 effect
    const { deps } = effect;
    for (let i = 0; i < deps.length; i++) {
        deps[i].delete(effect); // 清除属性对应的 effect，以便吃重新进行依赖收集
    }

    effect.deps.length = 0;
}
export class ReactiveEffect {
    // 控制依赖收集，激活状态(true)收集，非激活状态(false)不收集，默认为 true
    public active = true;

    // 当前 effect 实例对象的父级 effect 实例对象
    public parent = null;

    // deps 用于存储代理对象的各个属性所对应的 effect 实例对象
    public deps = [];

    constructor(public fn, public scheduler) {}

    run() {
        // 若是非激活状态，则不需要进行依赖收集，仅执行函数即可
        if (!this.active) {
            return this.fn();
        }

        // 依赖收集的核心：是将当前的 effect 和将要渲染的属性关联到一起
        try {
            // 保存当前的 effect 实例，以及其父级 effect 实例
            this.parent = activeEffect;
            activeEffect = this;

            // 执行用户函数 this.run() 之前，先把之前收集的依赖清空
            cleanupEffect(this);

            // fn 就是传入 effect 的函数， 这里又传入了 ReactiveEffect 类中
            // 当调用 fn 即执行 this.fn() 时，因其内部会对代理对象进行访问或修改，
            // 所以，会触发代理对象的 get 或 set 函数。因此，我们可以通过这两个函数
            // 可进行依赖收集，同时，也能够获取被导出的全局变量 activeEffect，即 effect 实例
            return this.fn();
        } finally {
            // 执行完成后，进行重置。就是把当前的 effect 实例，变成其父级的 effect 实例。
            // 而当前 effect 实例的父级，则置为空。

            activeEffect = this.parent;
            this.parent = null;
        }
    }
    // 停止对响应式对象 effect 的收集
    stop() {
        if (this.active) {
            this.active = false;
            cleanupEffect(this);
        }
    }
}
// fn 函数，可以根据状态变化，重新执行。effect 可以嵌套。
export function effect(fn, options) {
    const scheduler = options ? options.scheduler : null;
    const _effect = new ReactiveEffect(fn, scheduler); // 创建响应式 effect
    const runner = _effect.run.bind(_effect); // 绑定 this 指向

    _effect.run(); // 默认执行一次
    runner.effect = _effect; // 将 effect 挂载到 runner 函数上

    return runner;
}

// target 是一个 Map，其中存着每个属性(key) 对应的 Set
// targetMap => { target: { key: new Set() } }
const targetMap = new WeakMap(); // WeakMap 持有的是每个键对象的“弱引用”，这意味着在没有其他引用存在时垃圾回收能正确进行

// 依赖收集
// 每个属性(key)，记录下其对应的 activeEffect 对象（可以有多个，但要避免重复），
// 每个 activeEffect 对象，记录下其收集过的属性（可以有多个，但要避免重复），
// 这种多对多的双向记录，便于清理不需要的对应关系。
export function track(target, type, key) {
    if (!activeEffect) return false;

    let depsMap = targetMap.get(target);
    if (!depsMap) {
        targetMap.set(target, (depsMap = new Map()));
    }

    let dep = depsMap.get(key);
    if (!dep) {
        depsMap.set(key, (dep = new Set()));
    }

    trackEffects(dep);
}
export function trackEffects(dep) {
    if (activeEffect) {
        let shouldTrack = !dep.has(activeEffect);
        if (shouldTrack) {
            dep.add(activeEffect); // 记录属性对应的 activeEffect
            activeEffect.deps.push(dep); // 记录 activeEffect 收集的属性
        }
    }
}
// 触发更新
export function trigger(target, type, key, value, oldValue) {
    const depsMap = targetMap.get(target);

    if (!depsMap) return false; // 触发的对象不存在，比如，未在模版中使用，或者说不曾被收集过
    let effects = depsMap.get(key); // 获取属性对应的 effect 对象

    if (effects) {
        triggerEffects(effects);
    }
}

export function triggerEffects(effects) {
    // 对于引用类型的对象，不要进行关联。执行之前，拷贝一份副本，用副本执行操作，以免造成死循环，导致栈溢出。
    effects = new Set(effects);
    effects.forEach(effect => {
        // 避免同一个 effect 重复调用，不然将导致栈溢出
        if (effect !== activeEffect) {
            if (effect.scheduler) {
                effect.scheduler(); // 若用户传入了调度函数，则进行调用
            } else {
                effect.run();
            }
        }
    });
}
