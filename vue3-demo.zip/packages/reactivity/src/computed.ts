import { isFunction } from '@vue/shared';
import { ReactiveEffect, trackEffects, triggerEffects } from './effect';

class ComputedRefImpl {
    public dep = new Set();
    private _value;
    public readonly effect;
    public readonly __v_isRef = true;
    public readonly __v_isReadonly = true;
    public _dirty = true; // 这是一个缓存标识，控制值的更新。 默认取值时，就进行计算。

    constructor(getters, private readonly _setter) {
        this.effect = new ReactiveEffect(getters, () => {
            // 如若依赖的属性发生变化，则在此处执行调度器
            if (!this._dirty) {
                this._dirty = true;
                // 实现触发更新
                triggerEffects(this.dep);
            }
        });
    }

    get value() {
        // 依赖收集
        trackEffects(this.dep);
        // _dirty 为真，就代表着值要更新
        if (this._dirty) {
            this._dirty = false;
            this._value = this.effect.run();
        }
        return this._value;
    }

    set value(newValue) {
        this._setter(newValue);
    }
}

// computed 是一个 effect，依赖的属性变化了，会更新 _dirty 的值，从而触发更新
// getterOrOptions 参数，可以是对象或函数
export function computed(getterOrOptions) {
    let getter;
    let setter;
    
    const onlyGetter = isFunction(getterOrOptions); // 是否为函数
    if (onlyGetter) {
        getter = getterOrOptions;
        setter = () => {
            console.warn('Write operation failed: computed value is readonly');
        };
    } else {
        getter = getterOrOptions.get;
        setter = getterOrOptions.set;
    }

    const cRef = new ComputedRefImpl(getter, setter);

    return cRef;
}
