import { isFunction, isObject } from '@vue/shared';
import { ReactiveEffect } from './effect';
import { isReactive } from './reactive';

/**
 * source：响应式数据或函数
 * cb 回调函数
 */

export function watch(source, cb) {
    let getter;

    // 响应式数据对象
    if (isReactive(source)) {
        // 因为 source 是响应式对象，所以，通过递归，循环访问此对象上的每一个属性，就可以收集各属性对应的 effect
        getter = () => traverse(source);
    } else if (isFunction(source)) {
        // 函数
        getter = source;
    } else {
        return false;
    }

    let oldValue;
    let cleanup;
    const onCleanup = fn => {
        cleanup = fn;
    };
    const job = () => {
        if (cleanup) cleanup(); // 后一次的 watch 触发上一次 watch 中的清除函数
        let newValue = effect.run(); // 调用回调，再次运行 run 函数，获取其最新值
        cb(newValue, oldValue, onCleanup);
        oldValue = newValue;
    };

    const effect = new ReactiveEffect(getter, job);
    oldValue = effect.run(); // 初始，运行 run 函数获取的值，做为老值
}

// 利用 set 解决对象循环引用问题，例如：obj: { a: obj }
export function traverse(value, set = new Set()) {
    if (!isObject(value)) return value;

    // 通过判断 value 是否已存在 set 中，来解决对象循环引用问题
    if (set.has(value)) return value;
    set.add(value);

    for (const key in value) {
        traverse(value[key], set);
    }

    return value;
}
// 问题：
// watch 监听某个响应式属性，通过并发请求接口更改属性值。
// 若第二次请求比第一次快，则会出现第一次属性值覆盖第二次的属性值，这和我们期望的后一次覆盖前一次不相符。

// 案例假设：
// 第一次调用: ajax('a') -> 执行 1s
// 第二次调用: ajax('b') -> 执行 0s

// 我们期待页面最后会渲染出 'b'，但因为请求完成的时间问题，会导致渲染出 'a'。

// 解决方案：后一次的 watch 触发上一次 watch 中的清除函数
// 第一次调用 watch 注入一个清除函数（每次调用都会注入一个清除函数）
// 第二次调用 watch 执行第一次注入的清除函数
// 第三次调用 watch 执行第二次注入的清除函数。以此类推。
