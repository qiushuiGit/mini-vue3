import { isArray, isObject } from '@vue/shared';
import { trackEffects, triggerEffects } from './effect';
import { reactive } from './reactive';

function toReactive(value) {
    return isObject(value) ? reactive(value) : value;
}
class RefImpl {
    public dep = new Set();
    public _value;
    public __v_isRef = true;

    constructor(public rawValue) {
        this._value = toReactive(rawValue);
    }

    get value() {
        trackEffects(this.dep);
        return this._value;
    }

    set value(newValue) {
        if (newValue !== this.rawValue) {
            this._value = toReactive(newValue);
            this.rawValue = newValue;
            triggerEffects(this.dep);
        }
    }
}
export function ref(value) {
    return new RefImpl(value);
}
class ObjectRefImpl {
    constructor(public obj, public key) {}
    get value() {
        return this.obj[this.key];
    }
    set value(newValue) {
        this.obj[this.key] = newValue;
    }
}
export function toRef(obj, key) {
    return new ObjectRefImpl(obj, key);
}
export function toRefs(obj) {
    const result = isArray(obj) ? new Array(obj.length) : {};
    for (const key in obj) {
        result[key] = toRef(obj, key);
    }

    return result;
}
export function proxyRefs(obj) {
    return new Proxy(obj, {
        get(target, key, receiver) {
            const result = Reflect.get(target, key, receiver);
            return result.__v_isRef ? result.value : result;
        },
        set(target, key, value, receiver) {
            const oldValue = target[key];
            
            if (oldValue.__v_isRef) {
                oldValue.value = value;
                return true;
            } else {
                return Reflect.set(target, key, value, receiver);
            }
        }
    });
}
