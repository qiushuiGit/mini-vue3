import { isObject } from '@vue/shared';
import { mutableHandlers } from './baseHandler';

// 缓存 target 的代理对象(proxy)，避免对其重复代理
export const reactiveMap = new WeakMap();
// 关于响应式的枚举对象
export const enum ReactiveFlags {
    IS_REACTIVE = '__v_isReactive', // 用于判断是否为代理对象
    RAW = '__v_raw' // 用于判断返回代理对象的原始对象
}
// 1) 将数据转化成响应式数据，只能做对象的代理
export function reactive(target) {
    return createReactiveObject(target, mutableHandlers, reactiveMap);
}

// done: 创建响应式对象
function createReactiveObject(target, baseHandlers, proxyMap) {
    // 若如果 target 不是对象，则直接返回
    if (!isObject(target)) {
        return target;
    }

    // 若 target 是已被代理过的 proxy 对象，它就会有 get 方法。
    // 在这种情况下， 访问 target[ReactiveFlags.IS_REACTIVE]，就会触发 target 的 get，
    // 然后得到返回值 true，接着进入 if 语句，来阻止重复代理，即避免代理对象 proxy 被多次代理。
    if (target[ReactiveFlags.IS_REACTIVE]) {
        return target;
    }

    // 若 target 已经代理过，则无需重复代理。用于避免同一个普通对象被多次代理。
    const exisitingProxy = proxyMap.get(target);
    if (exisitingProxy) return exisitingProxy;

    // Proxy 并未重新定义属性，只是代理。取值调用 get，赋值调用 set。
    const proxy = new Proxy(target, baseHandlers);
    proxyMap.set(target, proxy);

    return proxy;
}

// 是否为响应式对象
export function isReactive(value) {
    return !!(value && value[ReactiveFlags.IS_REACTIVE]);
}

// done: 返回代理对象的原始对象
export function toRaw(observed) {
    const raw = observed && observed[ReactiveFlags.RAW];
    return raw ? toRaw(raw) : observed;
}
