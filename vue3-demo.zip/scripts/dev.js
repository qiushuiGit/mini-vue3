const path = require('path');
const esbuild = require('esbuild');

// minimist 解析参数选项
// 例如： node scripts/dev.js reactivity -f global ——> { _: [ 'reactivity' ], f: 'global' }
const args = require('minimist')(process.argv.slice(2));
const target = args._[0] || 'reactivity'; // 需要打包的-文件夹名
const format = args.f || 'global'; // 打包格式
const pkg = require(path.resolve(__dirname, `../packages/${target}/package.json`));

// iife 立即执行函数 (function () {})()
// cjs node模块 module.exports
// esm 浏览器中的esModule模块 import
const outputFormat = format.startsWith('global') ? 'iife' : format === 'cjs' ? 'cjs' : 'esm';
const outfile = path.resolve(__dirname, `../packages/${target}/dist/${target}.${format}.js`);
const entryFile = path.resolve(__dirname, `../packages/${target}/src/index.ts`)

esbuild.build({
    entryPoints: [entryFile], // 打包入口文件
    outfile, // 打包后的文件
    bundle: true, // 把所有包打包到一起
    format: outputFormat, // 输入格式
    globalName: pkg.buildOptions.name, // 打包后的全局变量名
    platform: format === 'cjs' ? 'node' : 'browser', // 平台
    sourcemap: true,
    watch: {
        onRebuild(err) {
          console.log('onRebuild----->重新打包');
            if(err) console.log(err, '----->打包出错');
        }
    }
  }).then(() => {
    console.log('watching----->打包完成');
  })

