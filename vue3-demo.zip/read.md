# 依赖响应原理
1. 通过 new Proxy() 创建一个响应式对象
2. effect 默认数据变化要更新
    1) 首先将正在执行的 effect 作为全局变量
    2) 然后渲染（就是去取值），这时就可以在响应式对象(Proxy)的 get 方法中进行依赖收集
    3) 收集时，通过 WeakMap（ 形如：{ target: { key: val } } ） 进行存储

        targetMap => WeakMap

        target => Map

        key => 响应式对象的属性

        val => Set
3. 当用数据发生变化，通过对象属性来查找对应的 effect 集合，全部执行（即运行 run 函数），进行更新操作

# 分支切换-问题
#### 问题示例
```javascript
const { effect, reactive } = VueReactivity;
const data = { name: '秦始皇', age: 22, flag: true };
const state = reactive(data);
effect(() => {
    console.log(state.name, '渲染');
    // 分支切换
    document.getElementById('app').innerHTML = state.flag ? state.name : state.age;
});
setTimeout(() => {
    state.flag = false;
    setTimeout(() => {
        state.name = '测试'
    }, 1000);
}, 1000);
```
#### 问题分析
1. 初始时，`flag` 为 `true`，会渲染 name，并收集其依赖（即 name 对应的响应式对象）。
2. 过一秒后，设置 `flag` 为 `false`，则渲染 age，并收集其依赖（即 age 对应的响应式对象）。
3. 再过一秒后，对 name 赋值 `state.name = '测试'`，虽然，分支已被切换，但 name 的依赖依旧存在，它仍会重新渲染。

然而，分支切换，应只对符合条件的属性进行渲染并收集其依赖。当，`flag` 被设置为`false`时，我们应仅渲染 age，并收集其依赖，而name 的依赖应被清除。因此，我们需要一个清除依赖的函数——cleanupEffect，来解决这个问题。

